import bc.*;
public class Rocket{
    public static void oneMove(GameController gc, Unit unit, int strategy){
        // This does nothing rn
    }
}