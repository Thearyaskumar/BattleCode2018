//package bot;
public class EarthPlayer extends Player{
	
}