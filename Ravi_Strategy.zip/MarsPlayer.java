//package bot;
public class MarsPlayer extends Player{
	
}